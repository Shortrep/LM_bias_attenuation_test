def call_LM(prompt):
    return "yes"